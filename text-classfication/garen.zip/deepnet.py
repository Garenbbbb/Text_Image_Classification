import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import logistic
from tqdm import tqdm
from skimage import io
from matplotlib import pyplot as plt
import os
import numpy as np


# def imshow(img):
#     img = img / 2 + 0.5   
#     npimg = img.numpy()
#     plt.imshow(np.transpose(npimg, (1, 2, 0)))
#     plt.show()

# class Residual(nn.Module):
#     def __init__(self, in_channel, out_channel, use_1x1Conv=False, strides=1):
#         super().__init__()
#         self.conv1 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1, stride=strides)
#         self.bn1 = nn.BatchNorm2d(out_channel)
#         self.conv2 = nn.Conv2d(out_channel, out_channel, kernel_size=3, padding=1)
#         self.bn2 = nn.BatchNorm2d(out_channel)

#         if use_1x1Conv:
#             self.conv3 = nn.Conv2d(in_channel, out_channel, kernel_size=1, stride=strides)
#         else:
#             self.conv3 = None

#     def forward(self, X):
#         out = F.relu(self.bn1(self.conv1(X)))
#         out = self.bn2(self.conv2(out))
#         if self.conv3:
#             X = self.conv3(X)
#         out += X
#         return F.relu(out)

# def residualBlock(in_channel, out_channel, num_residuals, first_block=False):
#     blks = []
#     for i in range(num_residuals):
#         if i==0 and not first_block:
#             blks.append(Residual(in_channel, out_channel, use_1x1Conv=True,
#             strides=2))
#         else:
#             blks.append(Residual(out_channel, out_channel))
    
#     return blks

# class ResNet(nn.Module):
#     def __init__(self, input_channel, n_classes):
#         super().__init__()
#         self.b1 = nn.Sequential(
#             nn.Conv2d(input_channel, 64, kernel_size=7, stride=2, padding=3),
#             nn.BatchNorm2d(64),nn.ReLU(),
#             nn.MaxPool2d(kernel_size=3, stride=2, padding=1))
#         self.b2 = nn.Sequential(*residualBlock(64, 64, 2, first_block=True))
#         self.b3 = nn.Sequential(*residualBlock(64, 128, 2))
#         self.b4 = nn.Sequential(*residualBlock(128, 256, 2))
#         self.b5 = nn.Sequential(*residualBlock(256, 512, 2))
#         self.finalLayer = nn.Sequential(
#             nn.AdaptiveAvgPool2d((1,1)),
#             nn.Flatten(),nn.Linear(512, n_classes))

#         self.b1.apply(self.init_weights)
#         self.b2.apply(self.init_weights)
#         self.b3.apply(self.init_weights)
#         self.b4.apply(self.init_weights)
#         self.b5.apply(self.init_weights)
#         self.finalLayer.apply(self.init_weights)

#     def init_weights(self, layer):
#         if type(layer) == nn.Conv2d:
#             nn.init.kaiming_normal_(layer.weight, mode='fan_out')
#         if type(layer) == nn.Linear:
#             nn.init.normal_(layer.weight, std=1e-3)
#         if type(layer) == nn.BatchNorm2d:
#             nn.init.constant_(layer.weight, 1)
#             nn.init.constant_(layer.bias, 0)
        


#     def forward(self, X):
#         out = self.b1(X)
#         out = self.b2(out)
#         out = self.b3(out)
#         out = self.b4(out)
#         out = self.b5(out)
#         out = self.finalLayer(out)

#         return out
#net arcs
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 6, 5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(16 * 4 * 4, 2)
        # self.fc2 = nn.Linear(120, 84)
        # self.fc3 = nn.Linear(84, 2)
        

        

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1) # flatten all dimensions except batch
        x = self.fc1(x)
        #x = F.relu(self.fc1(x))
        # x = F.relu(self.fc2(x))
        # x = self.fc3(x)
        return x



def main():

    #load image
    all_image = io.imread_collection('image_data/*.png')

    #train_08000_train_47999 len 40000
    train_image = np.array(all_image[8000:48000])/255 #normalize the data
    train_image = torch.FloatTensor(train_image[:, np.newaxis, ...]) 
    train_label = torch.LongTensor(logistic.txt_process('train.txt'))

    #val 48000- 57999 len 10000
    val_image = np.array(all_image[48000:58000])/255 #normalize the data
    val_image = torch.FloatTensor(val_image[:, np.newaxis, ...])
    val_label = torch.LongTensor(logistic.txt_process('val.txt'))

    #create train data loader
    train_dataset = torch.utils.data.TensorDataset(train_image, train_label)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=32, shuffle=True, num_workers=2)

    #create validation data loader
    val_dataset = torch.utils.data.TensorDataset(val_image, val_label)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=32, num_workers=2)
    
    print("finish data processing\nstart training")

    # dataiter = iter(train_loader)
    # images, labels = dataiter.next()
    # # show images
    # imshow(utils.make_grid(images))
    # print(labels[i] for i in range(4))
    # return

    # dataiter = iter(train_loader)
    # images, labels = dataiter.next()
    # fig, ax = plt.subplots()
    # plt.imshow( images)
    # plt.show() 
    # print(labels)
    best_acc = 0
    PATH = './garen_net.pth'
    losses = []

    net = Net()
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(net.parameters(), lr=0.001, momentum=0.9) #Adam
    for epoch in range(2):  #   number of epoches
        net.train() #train mode
        running_loss = 0.0
        for i, data in tqdm(enumerate(train_loader, 0)):
            # get data -> [inputs, labels]
            inputs, labels = data

            # zero the parameter gradients
            optimizer.zero_grad()

            # forward, backward, optimize
            outputs = net(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            # print loss
            running_loss += loss.item()
            if i % 100 == 99:    # print every 100 mini-batches
                print(f'[{epoch + 1}, {i + 1:5d}] loss: {running_loss / 100:.3f}')
                losses.append(running_loss / 100)
                running_loss = 0.0
                total = 0
                correct = 0

                #testing
                net.eval() 
                with torch.no_grad():
                    for data in val_loader:
                        images, labels = data
                        # calculate outputs 
                        outputs = net(images)
                        # choose the highest prediction
                        _, predicted = torch.max(outputs.data, 1)
                        total += labels.size(0)
                        correct += (predicted == labels).sum().item()
                print(f'Accuracy of the network on the 10000 test images: {100 * correct / total} %')
                #print(labels, predicted)

                #save the best model
                if 100 * correct / total > best_acc:
                    best_acc = 100 * correct / total
                    torch.save(net.state_dict(), PATH)

                # show images
                #imshow(utils.make_grid(images))
                
    #print losses          
    plt.plot(losses)
    plt.ylabel('loss')
    plt.xlabel('100 mini-batches')
    plt.title('losses for Deep nrural network')
    plt.show()


                

    print('-------Finished------')

if __name__ == "__main__":
    main()